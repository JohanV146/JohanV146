#ifndef LISTAPLAYERS_HPP
#define LISTAPLAYERS_HPP

#include "nodoPlayer.hpp"


/*****Nombre***************************************
 * listaPlayers
 *****Descripción**********************************
 * crea una lista de jugadores, donde se guarda la informacion
 * del jugador.
 *****Atributos************************************
 * int countPlayer;
 * nodoPlayer *firstPlayer;
 *****Métodos**************************************
 * Metodo constructor
 * Metodos accesores
 * void insertPlayer (string pNombre)
 * void print()
 **************************************************/

class listaPlayers {
private:
	int countPlayer;
	nodoPlayer *firstPlayer;
public:
	// Metodo constructor
	listaPlayers () {
		this->countPlayer = 1;
		this->firstPlayer = nullptr;
	}

	/*****Nombre***************************************
	 * insertPlayer
	 *****Descripción**********************************
	 * Se encarga de insertar los jugadores en la lista
	 *****Entradas*************************************
	 * recibe un string nombre
	 **************************************************/
	void insertPlayer (string pNombre) {
		nodoPlayer *temp = new nodoPlayer(pNombre, countPlayer);
		temp->setNextPlayer (firstPlayer);
		firstPlayer = temp;
		countPlayer++;
	}

	/*****Nombre***************************************
	 * print
	 *****Descripción**********************************
	 * printa los nombres de los jugadores que se encuentran
	 * en la lista
	 **************************************************/
	void print(){
		for (nodoPlayer *v = firstPlayer; v != nullptr; v = v->getNextPlayer()){
			cout << v->getNombreP().c_str() << endl;
		}
	}

	// Metodo accesor
	int getCountPlayer(){ return countPlayer; }
	
	// Metodo accesor
	nodoPlayer* getFirstPlayer(){ return firstPlayer; }
	
	// Metodo accesor
	void setFirstPlayer(nodoPlayer *pFirstPlayer){ this->firstPlayer = pFirstPlayer; }
};

#endif // LISTAPLAYERS_HPP
