/*****Datos administrativos************************
 * Nombre del archivo: program.cpp
 * Tipo de archivo: cpp
 * Proyecto: proyecto extra
 * Autor: Johan Vargas Quesada
 *****Descripción**********************************
 * Es un juego de trivia, es un juego que se hacen
 * y si se responde bien se suman puntos y gana el
 * que tiene mas puntos.
 *****Versión**************************************
 * ## | Fecha y hora | Autor
 * 1  29-11-2022/ 2:00 AM  Johan Vargas Quesada
 **************************************************/

#include <iostream>
#include "list.hpp"
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include "ListaPlayers.hpp"

int lenP(char* direction);
void comienzo(listaPlayers *temp, list *n);
bool load(char* direction, list *n);
void categorias(listaPlayers *temp, list *n);
void players(listaPlayers *temp, list *n);
void identP(int pCantP, listaPlayers *temp, list *n);
void cantidaRondas(int pCantP, listaPlayers *temp, list *n);
void multiCategorias(listaPlayers *temp, list *n,int cRondas);
void juegoM(listaPlayers *temp, list *n, int cRondas, int rondaAct);
void juegoMAux(nodoPlayer *temp, list *n, int cRondas, int rondaAct, char* selectec);
void juegoN(listaPlayers *temp, list *n, int cRondas, int rondaAct);
void juegoNAux(nodoPlayer *temp, list *n, int cRondas, int rondaAct);
void desempate(listaPlayers *temp, list *n, int cRondas, int rondaAct);
void juegoNEmpAux(nodoPlayer *temp, list *n, int cRondas, int rondaAct);
string pegar(char* direction, string palabra);
void leer(string direccion, string palabra, list *n);

/*****Nombre***************************************
 * main
 *****Descripción**********************************
 * Es la clase main, inicializa las respectivas listas
 * y es donde se muestra si se quiere iniciar un juego
 * o salir
 **************************************************/
int main(){
	listaPlayers *temp = new listaPlayers();
	list *n = new list();
	char ini[3];
	int flag = 0;
	
	do {
		cout <<"==================================================\n|\t\t\t\t\t\t |\n|\t\tJuego de Trivia\t\t\t |\n|\t\t\t\t\t\t |\n==================================================" << endl;
		cout << "1. Comenzar\n2. Salir\nElija una opcion: ";
		fflush(stdin);
		cin >> ini;
		fflush(stdin);
		switch (atoi(ini)) {
			case 1:
				flag++;
	            break;
			case 2:
				return 1;
				break;
			default:
				break;
		}
	} while(flag != 1);
	comienzo(temp, n);			
}

/*****Nombre***************************************
 * comienzo
 *****Descripción**********************************
 * Se pide una direccion de un directorio donde se 
 * encuentran los txt para cargar las preguntas y 
 * categorias
 *****Entradas*************************************
 * listaPlayers *temp, list *n
 **************************************************/
void comienzo(listaPlayers *temp, list *n){
	char direction[100];
	int flag = 0;
	system("clear");
	cout <<"==================================================\n|\t\t\t\t\t\t |\n|\t\tJuego de Trivia\t\t\t |\n|\t\t\t\t\t\t |\n==================================================" << endl;
	do {	
		cout << "Ingrese la direccion del directorio: ";		
		fflush(stdin);
		scanf("%s", direction);
		fflush(stdin);
		if (load(direction, n)){
			flag++;
		} else {
			cout << "Error, ingrese un valor valido" << endl;
			//system("clear");
		}
	} while (flag != 1);
	categorias(temp, n);
}

/*****Nombre***************************************
 * load
 *****Descripción**********************************
 * abre el directorio y carga la informacion que se 
 * encuentra en el.
 *****Retorno**************************************
 * true si se encuentra la ubicacion del directorio
 * false de caso contrario.
 *****Entradas*************************************
 * char* direction
 **************************************************/
char* charAppend(char*pat,char*fil) { char* c = (char*)calloc(strlen(pat) + strlen((char*)fil) + 1, 1); memcpy(c, pat, strlen(pat)); memcpy(c + strlen(pat), (char*)fil, strlen((char*)fil)); return c; }
bool load(char* direction, list *n){
	char* palabra;
	string direc = "";
	string categ;
	string pos = "";
	DIR *dir;
	struct dirent *ent;
	dir = opendir(direction);
	if (dir){
		do {
			ent = readdir(dir);
			if (ent){
				pos = ent->d_name[0];
				if (pos != "."){
					categ = pegar(ent->d_name, palabra);	
					n->insertCategory(categ);
					leer(charAppend(direction,ent->d_name), categ, n);
				}
			}
		} while (ent);
		closedir(dir);
		return true;
	}else{ return false;}
}

/*****Nombre***************************************
 * categorias
 *****Descripción**********************************
 * Es donde se piden que categorias se quieren jugar
 *****Entradas*************************************
 * listaPlayers *temp, list *n
 **************************************************/
void categorias(listaPlayers *temp, list *n){
	char cat[3];
	char pregunta[3];
	int flag = 0;
	//system("clear");
	//cout <<"==================================================\n|\t\t\t\t\t\t |\n|\t\tJuego de Trivia\t\t\t |\n|\t\t\t\t\t\t |\n==================================================" << endl;
	n->printC();
	cout << "Ingrese la categoria que desea jugar: ";
	fflush(stdin);
	cin >> cat;
	fflush(stdin);
	if (n->seekCB(atoi(cat)) != false){	
		n->seekC(n->seekC(atoi(cat)))->setMark();
		do {
			cout << "Desea agregar otra categoria? (1 = si / 2 = No): ";
			fflush(stdin);
			cin >> pregunta;
			fflush(stdin);
			switch (atoi(pregunta)) {
				case 1:
					flag++;
			    		break;
				case 2:
					flag++;
					break;
				default:
					break;
			}
		} while(flag != 1);
		if (atoi(pregunta) == 1){
			categorias(temp, n);
		} else {
			players(temp, n);
		}
		
	} else {
		cout << "Error, no existe esa categoria, indique una nueva" << endl;
		categorias(temp, n);
	}
}

/*****Nombre***************************************
 * players
 *****Descripción**********************************
 * Es donde se pide cuantos jugadores van a jugar
 *****Entradas*************************************
 * listaPlayers *temp, list *n
 **************************************************/
void players(listaPlayers *temp, list *n){
	char ini[3];
	int flag = 0;
	int cantP;
	system("clear");
	cout <<"==================================================\n|\t\t\t\t\t\t |\n|\t\tJuego de Trivia\t\t\t |\n|\t\t\t\t\t\t |\n==================================================" << endl;
	do {
		cout << "Ingrese la cantidad de jugadores (1-6): ";
		fflush(stdin);
		cin >> ini;
		fflush(stdin);
		switch (atoi(ini)) {
			case 1:
				cantP = 1;
				flag++;
	            		break;
			case 2:
				cantP = 2;
				flag++;
				break;
			case 3:
				cantP = 3;
				flag++;
				break;
			case 4:
				cantP = 4;
				flag++;
				break;
			case 5:
				cantP = 5;
				flag++;
				break;
			case 6:
				cantP = 6;
				flag++;
				break;
			default:
				break;
		}
	} while (flag != 1);
	identP(cantP, temp, n);
}

/*****Nombre***************************************
 * identP
 *****Descripción**********************************
 * Es donde se ingresan los nombres de los jugadores
 *****Entradas*************************************
 * int pCantP, listaPlayers *temp, list *n
 **************************************************/
void identP(int pCantP, listaPlayers *temp, list *n){
	string name;
	char nombre[100];
	system("clear");
	cout <<"==================================================\n|\t\t\t\t\t\t |\n|\t\tJuego de Trivia\t\t\t |\n|\t\t\t\t\t\t |\n==================================================" << endl;
	cout << "Ingrese el nombre del jugador " << pCantP << ": ";
	fflush(stdin);
	cin >> nombre;
	fflush(stdin);
	name = nombre;
	temp->insertPlayer(name);
	if (pCantP > 1){
		identP(pCantP-1, temp, n);
	} else {
		cantidaRondas(pCantP, temp, n);
	}
}

/*****Nombre***************************************
 * cantidaRondas
 *****Descripción**********************************
 * Es donde se le pide al usuario la cantidad de rondas 
 * que desea jugar
 *****Entradas*************************************
 * int pCantP, listaPlayers *temp, list *n
 **************************************************/
void cantidaRondas(int pCantP, listaPlayers *temp, list *n){
	char ini[3];
	int flag = 0;
	system("clear");
	cout <<"==================================================\n|\t\t\t\t\t\t |\n|\t\tJuego de Trivia\t\t\t |\n|\t\t\t\t\t\t |\n==================================================" << endl;
	do {
		cout << "Ingrese la cantidad de rondas que desea jugar: ";
		fflush(stdin);
		cin >> ini;
		fflush(stdin);
		if (atoi(ini)*pCantP <= n->cantidadPreguntas()){
			flag++;
		} else cout << "No hay suficientes preguntas para esa cantidad de rondas" << endl;
	} while (flag != 1);
	multiCategorias(temp, n, atoi(ini));
}

/*****Nombre***************************************
 * multiCategorias
 *****Descripción**********************************
 * Es donde se valida si es un juego multi-categoria
 *****Entradas*************************************
 * listaPlayers *temp, list *n, int cRondas
 **************************************************/
void multiCategorias(listaPlayers *temp, list *n, int cRondas){
	if (n->cantidadCategorias() > 1){
		system("clear");
		juegoM(temp, n, cRondas, 1);
	} else {
		system("clear");
		juegoN(temp, n, cRondas, 1);
	}
}

/*****Nombre***************************************
 * juego
 *****Descripción**********************************
 * Es donde se puede comenzar a jugar
 *****Entradas*************************************
 * listaPlayers *temp, list *n, bool multi, int cRondas, int rondaAct
 **************************************************/
void juegoM(listaPlayers *temp, list *n, int cRondas, int rondaAct){
	int flag = 0;
	char respuesta[2];
	for (nodoPlayer *p = temp->getFirstPlayer(); p != nullptr; p = p->getNextPlayer()){
		cout << "Turno de " << p->getNombreP() << endl;
		cout << "Ronda actual " << rondaAct << endl;
		n->mostrarCategorias();
		char select[3];
		do{
			cout << "Ingrese la categoria que desea jugar: ";
			fflush(stdin);
			cin >> select;
			fflush(stdin);
			if (n->seekC(n->seekC(atoi(select)))->getMark() == true){
				flag++;
			} else{
				cout << "La categoria no es valida" << endl;
			}
		} while (flag != 1);
		flag = 0;
		juegoMAux(p, n, cRondas, rondaAct, select);
	}
	if (temp->validarEmpate() == true && cRondas <= 1){
		temp->marcarEmpate();
		desempate(temp, n, cRondas, rondaAct+1);
	} 
	if (temp->validarEmpate() != true && cRondas <= 1){
		cout << "EL ganador es " << temp->ganador().c_str() << endl;
	} 
	if (cRondas > 1) {
		juegoM(temp, n, cRondas-1, rondaAct+1);
	}
}

void juegoMAux(nodoPlayer *temp, list *n, int cRondas, int rondaAct, char* selectec){
	int flag = 0;
	
	node* a = n->generar(n->seekC(n->seekC(atoi(selectec))));
	cout << a->getDato().c_str() << "\n" << endl;
	cout << a->getOptions().c_str() << "\n" << endl;
	char respuesta[2];
	do{
		cout << "Ingrese el numero de la opcion que desea seleccionar: ";
		fflush(stdin);
		cin >> respuesta;
		fflush(stdin);
		if (atoi(respuesta) < 10 && atoi(respuesta) > 0){
			flag++;
		} else{
			cout << "La opcion no es valida" << endl;
		}
	}while(flag != 1);
	if (a->getResponse() == respuesta){
		temp->setScore(1*rondaAct);
		a->setMark();
		cout << "Respuesta correcta" << endl;
	} else{
		cout << "Respuesta incorrecta" << endl;
	}	
}

void juegoN(listaPlayers *temp, list *n, int cRondas, int rondaAct){
	for (nodoPlayer *p = temp->getFirstPlayer(); p != nullptr; p = p->getNextPlayer()){
		juegoNAux(p, n, cRondas, rondaAct);	
	}
	if (temp->validarEmpate() == true && cRondas <= 1){
		temp->marcarEmpate();
		desempate(temp, n, cRondas, rondaAct+1);
	} 
	if (temp->validarEmpate() != true && cRondas <= 1){
		cout << "EL ganador es " << temp->ganador().c_str() << endl;
	} 
	if (cRondas > 1) {
		juegoN(temp, n, cRondas-1, rondaAct+1);
	}
}

void juegoNAux(nodoPlayer *temp, list *n, int cRondas, int rondaAct){
	char respuesta[2];
	int flag = 0;
	cout << "Turno de " << temp->getNombreP() << endl;
	cout << "Ronda actual " << rondaAct << endl;
	
	node* v = n->getPregunta();
	node* a = n->generar(v);
	cout << a->getDato().c_str() << "\n" << endl;
	cout << a->getOptions().c_str() << "\n" << endl;
	do{
		cout << "Ingrese el numero de la opcion que desea seleccionar: ";
		fflush(stdin);
		cin >> respuesta;
		fflush(stdin);
		if (atoi(respuesta) < 10 && atoi(respuesta) > 0){
			flag++;
		} else{
			cout << "La opcion no es valida" << endl;
		}
	}while(flag != 1);
	if (a->getResponse() == respuesta){
		temp->setScore(1*rondaAct);
		a->setMark();
		cout << "Respuesta correcta" << endl;
	} else{
		cout << "Respuesta incorrecta" << endl;
	}	
}

void desempate(listaPlayers *temp, list *n, int cRondas, int rondaAct){
	if (n->verificarAll() != true){
		cout << "Desempate\n" << endl;
		for (nodoPlayer *p = temp->getFirstPlayer(); p != nullptr; p = p->getNextPlayer()){
			if (p->getMarkP() == true){
				juegoNEmpAux(p, n, cRondas, rondaAct);
			}
		}
		temp->clearAll();
		if (temp->validarEmpate() != true){
			cout << "EL ganador es " << temp->ganador().c_str() << endl;
		} else {
			temp->marcarEmpate();
			desempate(temp, n, cRondas, rondaAct+1);
		}
	} else {
		cout << "Se determina un empate" << endl;
	}
}

void juegoNEmpAux(nodoPlayer *temp, list *n, int cRondas, int rondaAct){
	char respuesta[2];
	int flag = 0;
	cout << "Turno de " << temp->getNombreP() << endl;
	cout << "Ronda actual " << rondaAct << endl;
	
	node* a = n->generarEmp();
	cout << a->getDato().c_str() << "\n" << endl;
	cout << a->getOptions().c_str() << "\n" << endl;
	do{
		cout << "Ingrese el numero de la opcion que desea seleccionar: ";
		fflush(stdin);
		cin >> respuesta;
		fflush(stdin);
		if (atoi(respuesta) < 10 && atoi(respuesta) > 0){
			flag++;
		} else{
			cout << "La opcion no es valida" << endl;
		}
	}while(flag != 1);
	if (a->getResponse() == respuesta){
		temp->setScore(1*rondaAct);
		a->setMark();
		cout << "Respuesta correcta" << endl;
	} else{
		cout << "Respuesta incorrecta" << endl;
	}
}

/*****Nombre***************************************
 * pegar
 *****Descripción**********************************
 * Le quita el .txt a las palabras ingresadas
 *****Retorno**************************************
 * Retorna el nombre sin el .txt
 *****Entradas*************************************
 * char* direction, string palabra
 **************************************************/
string pegar(char* direction, string palabra){
	palabra = "";
	int large = strlen(direction)-4;
	int cont = 0;
	while (cont != large){
		palabra += direction[cont];
		cont++;
	}
	return palabra;
}

void leer(string direccion, string palabra, list *n){
	char c;
	string almacenar = "";
	string almacenarP = "";
	string almacenarO = "";
	string almacenarR = "";
	int cantOpciones = 0;
	int cantPreg = 0;
	FILE *fp1;
    
	fp1 = fopen((char*)(direccion.c_str()), "r"); // abre el archivo
	if (fp1 != NULL){ // se verifica que se abra el archivo
		c = fgetc(fp1); // AVANZA POSICION 
		while(!feof(fp1)){ // SE REPITE HASTA QUE EL ARCHIVO ESTE VACIO
			if (int(c) == 91){ // 91 = [
				c = fgetc(fp1); // Esta en P
				if (int(c) == 80){ // 80 = P
					c = fgetc(fp1); // Esta en ]
					c = fgetc(fp1); // Esta en :
					c = fgetc(fp1); // Esta en [
					c = fgetc(fp1); // Esta en la primera letra del contenido
					while (int(c) != 82){ // Mientras que la c sea diferente de 82 = R
						if (int(c) == 93 ){ // 93 = ]
							if (cantPreg == 1){
								cantOpciones++;
								almacenarO += to_string(cantOpciones);
								almacenarO += ". ";
								almacenarO += almacenar;
								almacenarO += "\n";
								almacenar = "";
								c = fgetc(fp1);
								c = fgetc(fp1);
							} else { 
								almacenarP = almacenar;
								cantPreg++;
								almacenar = "";
								c = fgetc(fp1);
								c = fgetc(fp1);
							}
						}
						if (int(c) == 91){ // 91 = [
							c = fgetc(fp1);
							if (int(c) == 79){ // 79 = O
								c = fgetc(fp1);
								c = fgetc(fp1);
								c = fgetc(fp1);
							}
						} else {
							almacenar += c;
							c = fgetc(fp1);
						}
					}
					c = fgetc(fp1);
					c = fgetc(fp1);
					c = fgetc(fp1);
                    			c = fgetc(fp1);
					while (int(c) != 93){ // 93 = ]
						almacenar += c;
                        			c = fgetc(fp1);
					}
					almacenarR = almacenar;
					almacenar = "";
					cantOpciones = 0;
					cantPreg = 0;
					c = fgetc(fp1);
                    			c = fgetc(fp1);
				}
			}
			n->insertQuestion (palabra, almacenarP, almacenarO, almacenarR);
			//cout << almacenarP.c_str() << endl;
			//cout << almacenarO.c_str() << endl;
			//cout << almacenarR.c_str() << endl;
			almacenarP = "";
			almacenarO = "";
			almacenarR = "";
		}
		fclose(fp1); // cierre de archivo
	}else{
		cout << "No se pudo abrir el archivo" << endl;
	}
}

