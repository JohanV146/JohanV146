#ifndef LIST_HPP
#define LIST_HPP

#include "node.hpp"

/*****Nombre***************************************
 * list
 *****Descripción**********************************
 * Es una clase lista, crea una lista adyacente, 
 * similar a la de un grafo, donde guarda las
 * categorias y preguntas para el juego de trivia
 *****Atributos************************************
 * int countC;
 * int countP;
 * node *first;
 *****Métodos**************************************
 * Metodo constructor
 * Metodos accesores
 * void insertCategory (string pCategory)
 * void insertQuestion (string pCategory, string pQuestion, string pOptions, string pResponse)
 * bool seekCB (int i)
 * string seekC (int i)
 * node* seekC (string v) 
 * void printC()
 * int cantidadPreguntas()
 * int cantidadCategorias()
 * void mostrarCategorias()
 **************************************************/
class list {
private:
	int countC;
	int countP;
	node *first;
public:
	// Metodo constructor
	list () {
		this->countC = 1;
		this->countP = 1;
		this->first = nullptr;
	}

	/*****Nombre***************************************
	 * insertCategory
	 *****Descripción**********************************
	 * Se encarga de insertar las categorias del juego
	 *****Entradas*************************************
	 * string pCategory
	 **************************************************/
	void insertCategory (string pCategory) {
		node *temp = new node(pCategory, countC);
		temp->setNextC (first);
		first = temp;
		countC++;
	}

	/*****Nombre***************************************
	 * insertQuestion
	 *****Descripción**********************************
	 * Se encarga de insertar las preguntas en las categorias
	 * correspondientes
	 *****Entradas*************************************
	 * string pCategory
	 * string pQuestion
	 * string pOptions
	 * string pResponse
	 **************************************************/
	void insertQuestion (string pCategory, string pQuestion, string pOptions, string pResponse) {
		node *n1 = seekC (pCategory);

		if (n1 == nullptr) {
			insertCategory (pCategory);
			n1 = seekC (pCategory);
		}

		node *t = n1->getNextP ();
		node *n = new node (pQuestion, pOptions, pResponse, countP);
		countP++;

		n1->setNextP (n);
		n->setNextP (t);
	}
	
	/*****Nombre***************************************
	 * seekCB
	 *****Descripción**********************************
	 * comprueba si existe la categoria
	 *****Retorno**************************************
	 * retorna un true si existe la categoria y un false
	 * de caso contrario
	 *****Entradas*************************************
	 * int id
	 **************************************************/
	bool seekCB (int i) {
		if (i >= countC)
			return false;
		for (node *t = first; t != nullptr; t = t->getNextC ()){
			if (t->getId() == i)
				return true;
		}
		return false;
	}
	
	/*****Nombre***************************************
	 * seekC
	 *****Descripción**********************************
	 * Busca La categoria por ID
	 *****Retorno**************************************
	 * retorna el nombre del dato si es encontardo el id 
	 * de caso contrario retorna un valor nulo
	 *****Entradas*************************************
	 * int id
	 **************************************************/
	string seekC (int i) {
		for (node *t = first; t != nullptr; t = t->getNextC ()){
			if (t->getId() == i)
				return t->getDato();
		}
		return nullptr;
	}

	/*****Nombre***************************************
	 * seekC
	 *****Descripción**********************************
	 * Busca la categoria por nombre
	 *****Retorno**************************************
	 * retorna el puntero de la categoria si es encontrada
	 * y retorna un valor nulo de caso contrario
	 *****Entradas*************************************
	 * el nombre de la categoria
	 **************************************************/
	node* seekC (string v) {
		for (node *t = first; t != nullptr; t = t->getNextC ())
			if (t->getDato() == v)
				return t;
		return nullptr;
	}
	
	/*****Nombre***************************************
	 * printC
	 *****Descripción**********************************
	 * Printa las categorias que no estan marcadas con
	 * un true en mark
	 **************************************************/
	void printC(){
		for (node *v = first; v != nullptr; v = v->getNextC()){
			if (v->getMark() != true)
				cout << v->getId() << ". " << v->getDato().c_str() << endl;
		}
	}
	
	/*****Nombre***************************************
	 * cantidadPreguntas
	 *****Descripción**********************************
	 * cuenta las preguntas que estan marcadas con un true
	 * en sus categorias
	 *****Retorno**************************************
	 * retorna la cantidad de preguntas en total de todas 
	 * las categorias marcadas con un true en mark
	 **************************************************/
	int cantidadPreguntas(){
		int cont = 0;
		for (node *v = first; v != nullptr; v = v->getNextC()){
			if (v->getMark() == true){
				for (node *a = v->getNextP(); a != nullptr; a = a->getNextP()){
					cont++;
				}
			}
		}
		return cont;
	}
	
	/*****Nombre***************************************
	 * cantidadCategorias
	 *****Descripción**********************************
	 * cuenta las categorias marcadas con un true en mark
	 *****Retorno**************************************
	 * retorna la cantidad de categorias marcadas
	 **************************************************/
	int cantidadCategorias(){
		int cont = 0;
		for (node *v = first; v != nullptr; v = v->getNextC()){
			if (v->getMark() == true){
				cont++;
			}
		}
		return cont;
	}
	
	/*****Nombre***************************************
	 * mostrarCategorias
	 *****Descripción**********************************
	 * muestra las categorias marcadas con un true en 
	 * mark
	 **************************************************/

	void mostrarCategorias(){
		for (node *v = first; v != nullptr; v = v->getNextC()){
			if (v->getMark() == true)
				cout << v->getId() << ". " << v->getDato().c_str() << endl;
		}
	}

	// Metodo accesor
	int getcountC(){ return countC; }
	
	// Metodo accesor
	int getcountP(){ return countP; }
	
	// Metodo accesor
	node* getFirst(){ return first; }

	// Metodo accesor
	void setFirst(node *pFirst){ this->first = pFirst; }
};

#endif // LIST_HPP
