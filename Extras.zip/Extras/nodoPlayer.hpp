#ifndef NODOPLAYER_HPP
#define NODOPLAYER_HPP

/*****Nombre***************************************
 * nodoPlayer
 *****Descripción**********************************
 * es una clase normal de nodos, donde se guardan
 * jugadores y informacion para el juego de trivia.
 *****Atributos************************************
 * string nombre;
 * int score;
 * int id;
 * nodoPlayer *nextPlayer;
 *****Métodos**************************************
 * Metodo constructor
 * Metodos accesores
 **************************************************/
class nodoPlayer {
private:
	string nombre;
	int score;
	int id;
	nodoPlayer *nextPlayer;
public:
	// Metodo constructor
	nodoPlayer (string pNombre, int pId) {
		this->nombre = pNombre;
		this->score = 0;
		this->id = pId;
		this->nextPlayer = nullptr;
	}

	// Metodo accesor
	string getNombreP(){ return nombre; }
	
	// Metodo accesor
	int getScore(){ return score; }
	
	// Metodo accesor
	int getIdP(){ return id; }
	
	// Metodo accesor
	nodoPlayer* getNextPlayer(){ return nextPlayer; }

	// Metodo accesor
	void setNextPlayer(nodoPlayer *pNextPlayer){ nextPlayer = pNextPlayer; }
	
	// Metodo accesor
	void setScore(){ score++; }

};
#endif // NODOPLAYER_HPP
